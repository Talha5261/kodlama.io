public class Main {
    public static void main(String[] args) {

        dortislem dortislem=new dortislem();
        System.out.println(dortislem.topla(2,3));
        System.out.println(dortislem.topla(3,5,9));

    }
}