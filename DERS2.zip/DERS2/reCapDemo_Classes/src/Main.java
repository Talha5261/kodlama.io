public class Main {
    public static void main(String[] args) {

        DortIslem DortIslem = new DortIslem();
        int Sonuc = DortIslem.topla(3,5);
        int Sonuc2 = DortIslem.cikar(5,9);
        int Sonuc3 = DortIslem.carp(9,8);
        int Sonuc4 = DortIslem.bol(5,3);
        System.out.println(Sonuc);
        System.out.println(Sonuc2);
        System.out.println(Sonuc3);
        System.out.println(Sonuc4);
    }
}