public class Main {
    public static void main(String[] args) {
        KrediUI KrediUI = new KrediUI();
        KrediUI.KrediHesapla(new OgretmenKrediManager());


    }
}