public class KrediUI {
    public void KrediHesapla(BaseKrediManager BaseKrediManager){
        BaseKrediManager.Hesapla();


    }

}
