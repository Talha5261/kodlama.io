public class BaseKrediManager {
    public void Hesapla(){
        System.out.println("Kredi Hesaplandı.");

    }
}
