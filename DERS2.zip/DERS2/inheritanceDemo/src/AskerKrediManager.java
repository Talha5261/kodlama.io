public class AskerKrediManager extends BaseKrediManager{

}
