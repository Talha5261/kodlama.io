public class Main {

    public static void main(String[] args) {

            double [] myList ={7.35,5.40,3.50,5.25};
            double total=0;
            double max = myList[0];


            for (double number:myList){
                if (max<number);{
                max=number;}

            total= total + number;


            System.out.println(number);
        }

           System.out.println("TOPLAM SAYI = " + total);
            System.out.println("MAX SAYI = " + max);




    }
}