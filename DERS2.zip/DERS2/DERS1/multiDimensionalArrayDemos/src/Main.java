public class Main {
    public static void main(String[] args) {

        String [] [] sehirler = new String[3][3];

        sehirler [0] [0] = "İSTANBUL";
        sehirler [0] [1] = "BURSA";
        sehirler [0] [2] = "BALIKESİR";
        sehirler [1] [0] = "ANTALYA";
        sehirler [1] [1] = "ADANA";
        sehirler [1] [2] = "MUĞLA";
        sehirler [2] [0] = "ORDU";
        sehirler [2] [1] = "SAMSUN";
        sehirler [2] [2] = "TRABZON";

        for (int i=0; i<=2;i++ ){
            System.out.println("--------------------");
            for(int j=0; j<=2; j++)

                System.out.println(sehirler [i][j]);
        }







    }
}