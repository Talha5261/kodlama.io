public class Main {
    public static void main(String[] args) {
        int[] sayilar = new int[]{1, 3, 5, 7, 8, 9};
        int aranacak = 4;
        boolean varMi = false;


        for (int sayi : sayilar) {
            if (sayi == aranacak) {
                varMi = true;
                break;

            }
        }
        if (varMi) {
            System.out.println("SAYILAR ARASINDA VARDRIR.");
        } else {
            System.out.println("ARANAN SAYI YOKTUR.");
        }

    }
}