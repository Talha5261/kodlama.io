public class Main {
    public static void main(String[] args) {
        int sayi = 18;
        if(sayi<20) {
            System.out.println("SAYI 20'DEN KÜÇÜKTÜR");
        }else if (sayi==20){
            System.out.println("SAYI 20'YE EŞİTTİR.");

        }else{
            System.out.println("SAYI 20'DEN BÜYÜKTÜR.");
        }

    }
}