public class Main {
    public static void main(String[] args) {
        String[] ogrenciler = new String[4];
        ogrenciler[0] = "MUHAMMET";
        ogrenciler[1] = "TALHA";
        ogrenciler[2] = "EMRE";
        ogrenciler[3] = "KÖMERİK";

        for (int i = 0; i < ogrenciler.length; i++) {
            System.out.println(ogrenciler[i]);

        }
        for (String ogrenci : ogrenciler) ;
        {

            System.out.println(ogrenci);
        }

    }
}

