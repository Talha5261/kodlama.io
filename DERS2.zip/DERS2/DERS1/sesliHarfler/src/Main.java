public class Main {
    public static void main(String[] args) {

        char harf = 'I';

        switch (harf){
            case 'A':
            case 'I':
            case 'O':
            case 'U':
                System.out.println("KALIN SESLİ HARF GİRDİNİZ.");
                break;
            default:
                System.out.println("İNCE SESLİ HARF GİRDİNİZ");

        }

    }
}