public class Main {
    public static void main(String[] args) {
        int number = 1;
        int remainder = number % 2 ;
        System.out.println(remainder);
        boolean isPrime = true;

        if (number==1){
            System.out.println("SAYI ASAL DEĞİLDİR EN KÜÇÜK ASAL SAYI 2 DİR.");
            return;
        }

        if (number<1){
            System.out.println("GEÇERSİZ SAYI GİRDİNİZ.");
        }


            for (int i = 2; i < number; i++) {
                if (number % i == 0) {
                    isPrime = false;

                }
            }
            if (isPrime) {
                System.out.println("SAYI ASALDIR.");
            } else {
                System.out.println("SAYI ASAL DEĞİLDİR.");
            }

        }
    }
