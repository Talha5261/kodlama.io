public class Main {
    public static void main(String[] args) {
        String mesaj = "BUGÜN HAV ÇOK GÜZEL.";
        String yeniMesaj = sehirVer();
        System.out.println(yeniMesaj);
        int sayi = topla(5,7);
        System.out.println(sayi);
        int toplam = topla2(2,5,7,9,11,20,22,23,25,28,32,33,36,36,38);
        System.out.println(toplam);




    }
    public static void ekle() {
        System.out.println("EKLENDİ");

    }
    public static void sil() {
        System.out.println("SİLİNDİ");

    }
    public static void güncelle(){
        System.out.println("GÜNCELLENDİ");

    }
    public static String sehirVer(){
        return "İSTANBUL";

    }
    public static int topla2(int... sayilar ){
        int toplam = 0;
        for (int sayi:sayilar){
            toplam+=sayi;

        }
        return toplam;

    }


    public static int topla(int sayi1,int sayi2){
        return sayi1 +sayi2;
    }



}