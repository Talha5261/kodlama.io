public class Main {
    public static void main(String[] args) {
        String mesaj = "BUGÜN HAVA ÇOK GÜZEL.";

        System.out.println(mesaj);
        System.out.println("TOPLAM ELEMAN SAYISI :" + mesaj.length());
        System.out.println("BEŞİNCİ ELEMAN :" + mesaj.charAt(7));
        System.out.println(mesaj.concat(" YAŞASIN !"));
        System.out.println(mesaj.startsWith("B"));
        System.out.println(mesaj.endsWith("E"));
        char [] karakterler = new char[5];
        mesaj.getChars(0,5,karakterler,0);
        System.out.println(karakterler);
        System.out.println(mesaj.indexOf("A"));
        System.out.println(mesaj.lastIndexOf("A"));
        System.out.println(mesaj.replace("A","I"));
        System.out.println(mesaj.substring(3,13));
        System.out.println("-------------");

        for (String kelime : mesaj.split(" ")){
            System.out.println(kelime);
        }
        System.out.println("-----------------");
        System.out.println(mesaj.toLowerCase());
        System.out.println(mesaj.toUpperCase());




    }
}