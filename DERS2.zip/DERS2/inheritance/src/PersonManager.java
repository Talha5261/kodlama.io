public class PersonManager  {

    public void list() {
        System.out.println("Müşteri Listelendi.");
    }

    public void Add() {
        System.out.println("Müşteri Eklendi.");

    }
}
