public class Customer extends Person {

    String email;

}
