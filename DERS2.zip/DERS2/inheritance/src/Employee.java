public class Employee extends Person  {

    double salary;


}
