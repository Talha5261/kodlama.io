public class EmployeeManager extends PersonManager{


    public void BestEmployee(){
        System.out.println("AYIN ELEMANI GETİRİLDİ.");
    }
}
