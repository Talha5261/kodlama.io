public class CustomerManager extends PersonManager {


}