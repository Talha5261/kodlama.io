public class Product {
    private int id;
    private String name;
    private String desripcition;
    private double price;
    private int stockAmount;
    private String renk;
    private int kod;

    public int get_id() {
        return id;

    }

    public void set_id(int id) {
        this.id = id;


    }

    public String get_name() {
        return _name;
    }

    public void set_name(String _name) {
        this._name = _name;
    }

    public String get_desripcition() {
        return _desripcition;
    }

    public void set_desripcition(String _desripcition) {
        this._desripcition = _desripcition;
    }

    public double get_price() {
        return _price;
    }

    public void set_price(double _price) {
        this._price = _price;
    }

    public int get_stockAmount() {
        return _stockAmount;
    }

    public void set_stockAmount(int _stockAmount) {
        this._stockAmount = _stockAmount;
    }

    public String get_renk() {
        return _renk;
    }

    public void set_renk(String _renk) {
        this._renk = _renk;
    }

    public int get_kod() {
        return _kod;
    }

    public void set_kod(int _kod) {
        this._kod = _kod;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesripcition() {
        return desripcition;
    }

    public void setDesripcition(String desripcition) {
        this.desripcition = desripcition;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStockAmount() {
        return stockAmount;
    }

    public void setStockAmount(int stockAmount) {
        this.stockAmount = stockAmount;
    }

    public String getRenk() {
        return renk;
    }

    public void setRenk(String renk) {
        this.renk = renk;
    }

    public int getKod() {
        return kod;
    }

    public void setKod(int kod) {
        this.kod = kod;
    }
}

