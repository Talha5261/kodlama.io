public class ProductManager {
    public void Add (Product product){
        System.out.println("ÜRÜN EKLENDİ: "  + product.getName());
    }

    public void Add2 (int id, String name, String description, int stockAmount, double price){

    }
}
