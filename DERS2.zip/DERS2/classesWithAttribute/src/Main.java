public class Main {
    public static void main(String[] args) {
        Product Product = new Product();
        Product.setName("LAPTOP");
        Product.setDesripcition("LENOVO LAPTOP");
        Product.set_id(1);
        Product.setPrice(5000);
        Product.setStockAmount(50);

        ProductManager ProductManager = new ProductManager();
        ProductManager.Add(Product);




    }
}