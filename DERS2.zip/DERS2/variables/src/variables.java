public class variables {
}
