public class Main {
    public static void main(String[] args) {
        int ogrenciSayisi = 115;
        String mesaj = "öğrenci sayısı : ";

        System.out.println(mesaj +ogrenciSayisi );
        System.out.println(mesaj +ogrenciSayisi );
        System.out.println("öğrenci sayısı :" +ogrenciSayisi );
        System.out.println("öğrenci sayısı :" +ogrenciSayisi );

    }
}