public class CustomerManager {

    public void Add(){
        System.out.println("MÜŞTERİ EKLENDİ");
    }

    public void Remove(){
        System.out.println("MÜŞTERİ SİLİNDİ");
    }

    public void Update(){
        System.out.println("MÜŞTERİ GÜNCELLENDİ");
    }
}
